﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MySql.Data.MySqlClient;

namespace Buscaminas
{
    public class DatabaseHelper
    {
        private const string ConnectionString = "Server=localhost;Database=buscaminas;User ID=root;Password=;";

        public static void SavePlayerScore(string playerName, int score)
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();

                using (MySqlCommand command = new MySqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "INSERT INTO players (Name, Score) VALUES (@Name, @Score)";
                    command.Parameters.AddWithValue("@Name", playerName);
                    command.Parameters.AddWithValue("@Score", score);

                    try
                    {
                        command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                }
            }
        }
    }
    public partial class MainWindow : Window
    {
        private const int Size = 10; // Tamaño del tablero
        private Button[,] buttons = new Button[Size, Size];
        private int[,] mineField = new int[Size, Size];
        private int score = 0;
        private string playerName = "";

        public MainWindow()
        {
            InitializeComponent();
            AskForPlayerName();
            InitializeGame();
        }

        private void AskForPlayerName()
        {
            playerName = Microsoft.VisualBasic.Interaction.InputBox("Por favor, ingrese su nombre:", "Nombre de jugador", "", -1, -1);
            if (string.IsNullOrEmpty(playerName))
            {
                playerName = "Jugador Anónimo";
            }
        }

        private void InitializeGame()
        {
            int mines = AskForMines();
            PlaceMines(mines);
            CalculateMines();
            CreateButtons();
        }

        private int AskForMines()
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("¿Cuántas minas deseas?", "Minas", "10", -1, -1);
            if (!int.TryParse(input, out int mines) || mines < 1 || mines > (Size * Size - 1))
            {
                MessageBox.Show("Número inválido de minas. Se usarán 10 minas por defecto.");
                mines = 10;
            }
            return mines;
        }

        private void PlaceMines(int mines)
        {
            Random rand = new Random();
            for (int i = 0; i < mines; i++)
            {
                int row, col;
                do
                {
                    row = rand.Next(Size);
                    col = rand.Next(Size);
                } while (mineField[row, col] == -1);
                mineField[row, col] = -1;
            }
        }

        private void CalculateMines()
        {
            for (int row = 0; row < Size; row++)
            {
                for (int col = 0; col < Size; col++)
                {
                    if (mineField[row, col] == -1) continue;

                    int minesCount = 0;
                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            int newRow = row + i;
                            int newCol = col + j;
                            if (newRow >= 0 && newRow < Size && newCol >= 0 && newCol < Size && mineField[newRow, newCol] == -1)
                            {
                                minesCount++;
                            }
                        }
                    }
                    mineField[row, col] = minesCount;
                }
            }
        }

        private void CreateButtons()
        {
            for (int row = 0; row < Size; row++)
            {
                for (int col = 0; col < Size; col++)
                {
                    Button button = new Button
                    {
                        Margin = new Thickness(0),
                        Tag = $"{row},{col}"
                    };
                    button.Click += Button_Click;
                    button.MouseRightButtonDown += Button_MouseRightButtonDown;
                    buttonsGrid.Children.Add(button);
                    buttons[row, col] = button;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string tag = button.Tag.ToString();
            int row = int.Parse(tag.Split(',')[0]);
            int col = int.Parse(tag.Split(',')[1]);

            if (mineField[row, col] == -1)
            {
                RevealBomb(button);
                MessageBox.Show($"Juego terminado. Puntuación final: {score}", "Fin del juego", MessageBoxButton.OK, MessageBoxImage.Information);
                // Considerar implementar una funcionalidad para reiniciar el juego.
            }
            else
            {
                RevealCell(row, col);
            }
        }

        private void Button_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button button = sender as Button;
            if (button.IsEnabled)
            {
                if (button.Content is Image)
                {
                    button.Content = null; // Quitar la bandera
                }
                else
                {
                    Image flagImage = new Image
                    {
                        Source = new BitmapImage(new Uri(@"C:\Users\Feruz\source\repos\Buscaminas\Buscaminas\images\flag.png"))
                    };
                    button.Content = flagImage; // Establecer la bandera
                }
            }
            e.Handled = true; // Prevenir la propagación del evento
        }

        private void RevealCell(int row, int col)
        {
            Button button = buttons[row, col];
            if (button == null || !button.IsEnabled || button.Content is Image) return;

            button.IsEnabled = false;
            button.Opacity = 0.5; // Hacerlo semi-transparente para indicar revelación

            if (mineField[row, col] > 0)
            {
                button.Content = mineField[row, col].ToString();
            }

            score += 10;
            scoreTextBlock.Text = $"Puntuación: {score}";

            if (mineField[row, col] == 0)
            {
                // Revelar casillas adyacentes
                for (int i = -1; i <= 1; i++)
                {
                    for (int j = -1; j <= 1; j++)
                    {
                        if (i == 0 && j == 0) continue; // Saltarse a sí mismo
                        int newRow = row + i;
                        int newCol = col + j;
                        if (newRow >= 0 && newRow < Size && newCol >= 0 && newCol < Size)
                        {
                            RevealCell(newRow, newCol);
                        }
                    }
                }
            }
        }

        private void RevealBomb(Button button)
        {
            Image bombImage = new Image
            {
                Source = new BitmapImage(new Uri(@"C:\Users\Feruz\source\repos\Buscaminas\Buscaminas\images\flag.png"))
            };
            button.Content = bombImage;
        }
    }

}